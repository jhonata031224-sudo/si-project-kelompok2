// Fungsi Simulasi Login Pelanggan
function loginUser() {
    const user = document.getElementById('username').value;
    const pass = document.getElementById('password').value;

    if (user === "" || pass === "") {
        alert("⚠️ Kesalahan!\nUsername dan Password tidak boleh kosong.");
    } else if (user !== "fahry" || pass !== "12345678") {
        // Pop-up sesuai instruksi
        alert("❌ Gagal Masuk!\nUsername atau Password yang anda masukkan salah.");
    } else {
        alert("✅ Berhasil!\nSelamat datang di Prince Games.");
    }
}

// Fungsi Simulasi Login Staff/Owner
function loginStaff() {
    const email = document.getElementById('emailStaff').value;
    const pass = document.getElementById('passStaff').value;

    if (email === "" || pass === "") {
        alert("⚠️ Peringatan!\nEmail dan Password harus diisi.");
    } else if (!email.includes("@")) {
        alert("❌ Email Tidak Valid!\nFormat Gmail/Email salah.");
    } else if (pass.length < 8) {
        alert("❌ Sandi Salah!\nKata sandi staff minimal 8 karakter.");
    } else {
        alert("🚀 Akses Diterima!\nMenghubungkan ke sistem dashboard...");
    }
}