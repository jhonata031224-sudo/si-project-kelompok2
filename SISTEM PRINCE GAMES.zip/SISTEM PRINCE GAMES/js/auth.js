// js/auth.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-auth.js";

// 1. KONFIGURASI FIREBASE (Ganti dengan data dari Firebase Console Anda)
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAqa9FTlNuVXGHnINFN1qz8-aoGTrn-0g4",
  authDomain: "prince-games-f170a.firebaseapp.com",
  projectId: "prince-games-f170a",
  storageBucket: "prince-games-f170a.firebasestorage.app",
  messagingSenderId: "245728198046",
  appId: "1:245728198046:web:b613645f5f51b9fc3f6a8f",
  measurementId: "G-DEYHC96NNP"
};

// Inisialisasi Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Fungsi untuk menampilkan pesan error di UI (box merah)
function showError(msg) {
    const errorBox = document.getElementById('error-box');
    if (errorBox) {
        errorBox.innerText = msg;
        errorBox.style.display = 'block';
    }
}

// 2. HANDLER DAFTAR STAFF/OWNER
// Menggunakan Email asli dan Password sesuai instruksi
window.handleRegisterStaff = async () => {
    const email = document.getElementById('email-staff').value;
    const pass = document.getElementById('pass-staff').value;

    if (!email || !pass) return showError("Email dan Password wajib diisi!");

    try {
        await createUserWithEmailAndPassword(auth, email, pass);
        alert("Pendaftaran Staff Berhasil!");
        window.location.href = 'login-staff.html';
    } catch (error) {
        console.error("Register Error:", error.code);
        if (error.code === 'auth/email-already-in-use') showError("Email sudah terdaftar!");
        else if (error.code === 'auth/weak-password') showError("Password minimal 6 karakter!");
        else showError("Gagal daftar: " + error.message);
    }
};

// 3. HANDLER LOGIN STAFF
// Setelah sukses akan diarahkan ke dashboard-staff.html
window.handleLoginStaff = async () => {
    const email = document.getElementById('email').value;
    const pass = document.getElementById('password').value;

    if (!email || !pass) return showError("Harap isi email dan password!");

    try {
        await signInWithEmailAndPassword(auth, email, pass);
        alert("Akses Staff Diterima!");
        window.location.href = 'dashboard-staff.html';
    } catch (error) {
        showError("Email atau Password staff salah!");
    }
};

// 4. HANDLER LOGIN PELANGGAN
// Memetakan username menjadi email simulasi (@gmail.com) untuk Firebase Auth
window.handleLoginUser = async () => {
    const user = document.getElementById('username').value;
    const pass = document.getElementById('password').value;

    if (!user || !pass) return showError("Username dan Password wajib diisi!");

    const emailSimulasi = `${user}@gmail.com`;

    try {
        await signInWithEmailAndPassword(auth, emailSimulasi, pass);
        alert("Selamat datang, " + user + "!");
        window.location.href = 'dashboard-customer.html';
    } catch (error) {
        if (error.code === 'auth/user-not-found') showError("Username tidak ditemukan!");
        else if (error.code === 'auth/wrong-password') showError("Password salah!");
        else showError("Gagal login: " + error.message);
    }
};